<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class users extends Model
{
    protected $table="users";
    public $timestamps=false;
}
