<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class attr extends Model
{
    protected $table="attr";
    public $timestamps=false;
}
