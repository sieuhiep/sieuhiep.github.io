<?php $__env->startSection('title','them san pham'); ?>
<?php $__env->startSection('product'); ?>
    class="active"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_product'); ?>
    <script>

        function changeImg(input) {
            //Nếu như tồn thuộc tính file, đồng nghĩa người dùng đã chọn file mới
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                //Sự kiện file đã được load vào website
                reader.onload = function (e) {
                    //Thay đổi đường dẫn ảnh
                    $('#avatar').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $(document).ready(function () {
            $('#avatar').click(function () {
                $('#img').click();
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!--main-->
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">               
            <div class="col-lg-12">
                <h1 class="page-header">Thêm sản phẩm</h1>
            </div>
        </div>
        <!--/.row-->
        <div class="row">
            <div class="col-xs-6 col-md-12 col-lg-12">
                    <form method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?> 
                <div class="panel panel-primary">
                        <form action="" method="post"></form>
                    <div class="panel-heading">Thêm sản phẩm</div>
                    <div class="panel-body">
                        <div class="row" style="margin-bottom:40px">
                            <div class="col-xs-8">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label>Danh mục</label>
                                            <select name="category" class="form-control">
                                                <?php echo e(GetCategory($category,0,'',0)); ?>

                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Mã sản phẩm</label>
                                            <input  type="text" name="product_code" class="form-control">
                                            <?php if($errors->has('product_code')): ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('product_code')); ?></strong>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Tên sản phẩm</label>
                                            <input  type="text" name="product_name" class="form-control">
                                            <?php if($errors->has('product_name')): ?>
                                            <div class="alert alert-danger" role="alert">
                                                <strong><?php echo e($errors->first('product_name')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Giá sản phẩm (Giá chung)</label>
                                            <input  type="number" name="product_price" class="form-control">
                                            <?php if($errors->has('product_price')): ?>
                                            <div class="alert alert-danger" role="alert">
                                                <strong><?php echo e($errors->first('product_price')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Sản phẩm nổi bật</label>
                                            <select  name="featured" class="form-control">
                                                <option value="1">Có</option>
                                                <option value="0">Không</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Trạng thái</label>
                                            <select  name="product_state" class="form-control">
                                                <option value="1">Còn hàng</option>
                                                <option value="0">Hết hàng</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Ảnh sản phẩm</label>
                                            <?php if($errors->has('product_img')): ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('product_img')); ?></strong>
                                                </div>
                                            <?php endif; ?>
                                            <input id="img" type="file" name="product_img" class="form-control hidden"
                                                onchange="changeImg(this)">
                                            <img id="avatar" class="thumbnail" width="100%" height="350px" src="backend/img/import-img.png">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Thông tin</label>
                                    <textarea  name="info" style="width: 100%;height: 100px;"></textarea>
                                </div>

                            </div>
                            <div class="col-xs-4">

                                <div class="panel panel-default">
                                    <div class="panel-body tabs">
                                        <label>Các thuộc Tính <a href="admin/product/detail-attr"><span class="glyphicon glyphicon-cog"></span>
                                                Tuỳ chọn</a></label>
                                                <?php if($errors->has('attr_name')): ?>
                                                    <div class="alert  alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('attr_name')); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if($errors->has('value_name')): ?>
                                                    <div class="alert alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('value_name')); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(session('thongbao')): ?>
                                                <div class="alert alert-success" role="alert">
                                                <strong><?php echo e(session('thongbao')); ?></strong>
                                                </div>
                                            <?php endif; ?>
                                        <ul class="nav nav-tabs">
                                            <?php
                                                $i=0;
                                            ?>
                                            <?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li <?php if($i==0): ?> class='active' <?php endif; ?> ><a href="#tab<?php echo e($attr->id); ?>" data-toggle="tab"><?php echo e($attr->name); ?></a></li>
                                                <?php
                                                    $i=1;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                            
                                            <li><a href="#tab-add" data-toggle="tab">+</a></li>
                                        </ul>
                                        <div class="tab-content">
                                            <?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tab-pane fade <?php if($i==1): ?> active <?php endif; ?> in" id="tab<?php echo e($attr->id); ?>">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <th><?php echo e($value->value); ?></th>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                          
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <td> <input class="form-check-input" type="checkbox" name="attr[<?php echo e($attr->id); ?>][]"
                                                            value="<?php echo e($value->id); ?>"> </td>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <hr>
                                                <div class="form-group">
                                                    <form action="admin/product/add-value" method="post">
                                                        <?php echo csrf_field(); ?>
                                                    <label for="">Thêm giá trị cho thuộc tính</label>
                                                    <input type="hidden" name="attr_id" value="<?php echo e($attr->id); ?>">
                                                    <input name="value_name" type="text" class="form-control"
                                                        aria-describedby="helpId" placeholder="">
                                                    <div> <button name="add_val" type="submit">Thêm</button></div>
                                                    </form>
                                                </div>
                                            </div>
                                            <?php
                                                $i=2;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            <div class="tab-pane fade" id="tab-add">
                                                <form method="post" action="admin/product/add-attr">
                                                    <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <label for="">Tên thuộc tính mới</label>
                                                    <input type="text" class="form-control" name="attr_name"
                                                        aria-describedby="helpId" placeholder="">
                                                </div>

                                                <button type="submit" name="add_pro" class="btn btn-success"> <span
                                                        class="glyphicon glyphicon-plus"></span>
                                                    Thêm thuộc tính</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">

                                    <div class="form-check form-check-inline">
                                        <label class="form-check-label">
                                            <p></p>

                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Miêu tả</label>
                                        <textarea id="editor"  name="description" style="width: 100%;height: 100px;"></textarea>
                                    </div>
                                    <button class="btn btn-success" name="add-product" type="submit">Thêm sản phẩm</button>
                                    <button class="btn btn-danger" type="reset">Huỷ bỏ</button>
                                </div>
                            </div>
                        <div class="clearfix"></div>
                    </div>
                </div>

            </div>
        </div>

        <!--/.row-->
    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>