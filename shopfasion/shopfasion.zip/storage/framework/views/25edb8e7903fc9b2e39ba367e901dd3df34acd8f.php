<?php $__env->startSection('title','Thanh toán'); ?>
<?php $__env->startSection('content'); ?>
		<!-- main -->
		<form method="post" class="colorlib-form">
			<?php echo csrf_field(); ?>
		<div class="colorlib-shop">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-10 col-md-offset-1">
						<div class="process-wrap">
							<div class="process text-center active">
								<p><span>01</span></p>
								<h3>Giỏ hàng</h3>
							</div>
							<div class="process text-center active">
								<p><span>02</span></p>
								<h3>Thanh toán</h3>
							</div>
							<div class="process text-center">
								<p><span>03</span></p>
								<h3>Hoàn tất thanh toán</h3>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-7">
							<h2>Chi tiết thanh toán</h2>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="fname">Họ & Tên</label>
										<input name="name" type="text" id="fname" class="form-control" placeholder="First Name">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label for="fname">Địa chỉ</label>
										<input name="address" type="text" id="address" class="form-control" placeholder="Nhập địa chỉ của bạn">
									</div>
								</div>

								<div class="form-group">
									<div class="col-md-6">
										<label for="email">Địa chỉ email</label>
										<input name="email" type="email" id="email" class="form-control" placeholder="Ex: youremail@domain.com">
									</div>
									<div class="col-md-6">
										<label for="Phone">Số điện thoại</label>
										<input name="phone" type="text" class="form-control" placeholder="Ex: 0123456789">
									</div>
								</div>
								<div class="form-group">
									<div class="col-md-12">

									</div>
								</div>
							</div>
					</div>
					<div class="col-md-5">
						<div class="cart-detail">
							<h2>Tổng Giỏ hàng</h2>

							<ul>
								<li>

									<ul>
										<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><span><?php echo e($item->qty); ?> x <?php echo e($item->name); ?>

										<?php $__currentLoopData = $item->options->attr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											(<?php echo e($key); ?>:<?php echo e($value); ?>)
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</span> <span><?php echo e(number_format($item->price*$item->qty,0,'',',')); ?>VND</span></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</li>

								<li><span>Tổng tiền đơn hàng</span> <span><?php echo e($total); ?>VND</span></li>
							</ul>
						</div>

						<div class="row">
							<div class="col-md-12">
								<p><button class="btn btn-primary">Thanh toán</button></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- end main -->
	</form>
		<?php $__env->stopSection(); ?>	
<?php echo $__env->make('frontend.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>