<?php $__env->startSection('title','sua san pham'); ?>
<?php $__env->startSection('product'); ?>
    class="active"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script_product'); ?>
    <script>
        function changeImg(input) {
            //Nếu như tồn thuộc tính file, đồng nghĩa người dùng đã chọn file mới
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                //Sự kiện file đã được load vào website
                reader.onload = function (e) {
                    //Thay đổi đường dẫn ảnh
                    $('#avatar').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $(document).ready(function () {
            $('#avatar').click(function () {
                $('#img').click();
            });
        });

    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <form method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Sửa sản phẩm</h1>
            </div>
        </div>
        <!--/.row-->
        <div class="row">
            <div class="col-xs-6 col-md-12 col-lg-12">
            
                    <div class="panel panel-primary">
                        <div class="panel-heading"><?php echo e($product->name); ?> (<?php echo e($product->product_code); ?>)</div>
                        <div class="panel-body">
                                <?php if(session('thongbao')): ?>
                                <div class="alert alert-success" role="alert">
                                <strong><?php echo e(session('thongbao')); ?></strong>
                                    </div>
                                <?php endif; ?>
                            <div class="row" style="margin-bottom:40px">
                                <div class="col-xs-8">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="form-group">
                                                <label>Danh mục</label>
                                                <select name="category" class="form-control">
                                                    <?php echo e(GetCategory($category,0,'',$product->id)); ?>

                                                </select>
                                            </div>
                                            <div class="form-group">
                                            <label>Mã sản phẩm</label>
                                                <input  type="text" name="product_code" class="form-control" value="<?php echo e($product->product_code); ?>">
                                                <?php if($errors->has('product_code')): ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('product_code')); ?></strong>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label>Tên sản phẩm</label>
                                                <input  type="text" name="product_name" class="form-control" value="<?php echo e($product->name); ?>">
                                                <?php if($errors->has('product_name')): ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('product_name')); ?></strong>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                            <label>Giá sản phẩm (Giá chung): </label> <a href="admin/product/edit-variant/<?php echo e($product->id); ?>"><span
                                                        class="glyphicon glyphicon-chevron-right"></span>
                                                    Giá theo biến thể</a>
                                                <input  type="number" name="product_price" class="form-control" value="<?php echo e($product->price); ?>">
                                                <?php if($errors->has('product_price')): ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('product_price')); ?></strong>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label>Sản phẩm nổi bật</label>
                                                <select name="featured" class="form-control">
                                                    <option <?php if($product->featured==1): ?> selected <?php endif; ?> value="1">Có</option>
                                                    <option <?php if($product->featured==0): ?> selected <?php endif; ?> value="0">không</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Trạng thái</label>
                                                <select  name="product_state" class="form-control">
                                                    <option <?php if($product->state==1): ?> selected <?php endif; ?> value="1">Còn hàng</option>
                                                    <option <?php if($product->state==0): ?> selected <?php endif; ?> value="0">Hết hàng</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Ảnh sản phẩm</label>
                                                <?php if($errors->has('product_img')): ?>
                                                <div class="alert alert-danger" role="alert">
                                                    <strong><?php echo e($errors->first('product_img')); ?></strong>
                                                </div>
                                                <?php endif; ?>
                                                <input id="img" type="file" name="product_img" class="form-control hidden" onchange="changeImg(this)">
                                            <img id="avatar" name="product_img" class="thumbnail" width="100%" height="350px" src="public/backend/img/<?php echo e($product->img); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Thông tin</label>
                                    <textarea  name="info" style="width: 100%;height: 100px;"><?php echo e($product->info); ?></textarea>
                                    </div>
             

            </div>
            <div class="col-xs-4">

                <div class="panel panel-default">
                        <div class="panel-body tabs">
                                        <?php if($errors->has('attr_name')): ?>
                                            <div class="alert  alert-danger" role="alert">
                                            <strong><?php echo e($errors->first('attr_name')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($errors->has('value_name')): ?>
                                            <div class="alert alert-danger" role="alert">
                                            <strong><?php echo e($errors->first('value_name')); ?></strong>
                                            </div>
                                        <?php endif; ?>
                                <ul class="nav nav-tabs">
                                    <?php
                                        $i=0;
                                    ?>
                                    <?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li <?php if($i==0): ?> class='active' <?php endif; ?> ><a href="#tab<?php echo e($attr->id); ?>" data-toggle="tab"><?php echo e($attr->name); ?></a></li>
                                        <?php
                                            $i=1;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                            
                                </ul>
                                <div class="tab-content">
                                    <?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade <?php if($i==1): ?> active <?php endif; ?> in" id="tab<?php echo e($attr->id); ?>">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($value->value); ?></th>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                          
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td> <input <?php if(check_value($product,$value->id)): ?> checked <?php endif; ?> class="form-check-input" type="checkbox" name="attr[<?php echo e($attr->id); ?>][]" value="<?php echo e($value->id); ?>"> </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <hr>
                                    </div>
                                    <?php
                                        $i=2;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                               
                                </div>
                            </div>
                </div>
                <div class="form-group">

                    <div class="form-check form-check-inline">
                        <label class="form-check-label">
                            <p></p>

                        </label>
                    </div>
                </div>

            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Miêu tả</label>
                            <textarea id="editor"  name="description" style="width: 100%;height: 100px;"><?php echo e($product->describe); ?></textarea>

                        </div>


                        <button class="btn btn-success" name="add-product" type="submit">Sửa sản phẩm</button>
                        <button class="btn btn-danger" type="reset">Huỷ bỏ</button>

                    </div>

                </div>
            </div>

        </div>

        <div class="clearfix"></div>
    </div>
    </div>
    </div>
    </div>

    <!--/.row-->
    </form>
    </div>
    <!--end main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>