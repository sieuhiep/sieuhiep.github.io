<?php $__env->startSection('title','bien the'); ?>
<?php $__env->startSection('product'); ?>
    class="active"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="#"><svg class="glyph stroked home">
                            <use xlink:href="#stroked-home"></use>
                        </svg></a></li>
                <li class="active">Biến thể</li>
            </ol>
        </div>
        <!--/.row-->

        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Biến thể</h1>
            </div>
        </div>
        <!--/.row-->
        <div class="col-md-12">
            <div class="panel panel-default">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="panel-heading" align='center'>
                        Giá cho từng biến thể sản phẩm : <?php echo e($product->name); ?> (<?php echo e($product->product_code); ?>)
                    </div>
                    <div class="panel-body" align='center'>
                            <?php if(session('thongbao')): ?>
                            <div class="alert alert-success" role="alert">
                            <strong><?php echo e(session('thongbao')); ?></strong>
                            </div>
                            <?php endif; ?>
                        <table class="panel-body">
                            <thead>
                                <tr>
                                    <th width='33%'>Biến thể</th>
                                    <th width='33%'>Giá (có thể trống)</th>
                                    <th width='33%'>Tuỳ chọn</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php $__currentLoopData = $product->variant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                            <td scope="row">
                                                <?php $__currentLoopData = $item->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($row->attribute->name); ?> : <?php echo e($row->value); ?>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <input name="variant[<?php echo e($item->id); ?>]" class="form-control" placeholder="Giá cho biến thể" value="">
                                                </div>
                                            </td>
                                            <td>
                                            <a onclick="return del_variant()" id="" class="btn btn-warning" href="admin/product/delete-variant/<?php echo e($item->id); ?>" role="button">Xoá</a>
        
                                            </td>
        
                                        </tr>     
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div align='right'><button class="btn btn-success" type="submit"> Cập nhật </button> <a class="btn btn-warning"
                            href="admin/product" role="button">Bỏ qua</a></div>
                </form>
            </div>
        </div>

    </div>
    <!--/.main-->
    <script>
			function del_variant() {
				return confirm('Ban co chac muon xoa');
			}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>